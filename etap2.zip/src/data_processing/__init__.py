"""Data preparation and feature engineering."""
